<?php
//Zapobiega przekroczeniu czasu na serwerze
set_time_limit(0);

// Specjalna klasa dzięki której działa WebSocket. Serwer rozpoczyna pracę na samym końcu.
require 'class.PHPWebSocket.php';

//Wysyłanie danych na serwer przez klienta, pobierany jest ID, wysłana wiadomość i długość wiadomości
function wsOnMessage($clientID, $message, $messageLength, $binary) {
	global $Server;
	$ip = long2ip( $Server->wsClients[$clientID][6] );

	//Sprawdza czy napisano jakąś wiadomość, jeżeli nie to nic nie zostaje wysłane.
	if ($messageLength == 0) {
		$Server->wsClose($clientID);
		return;
	}

	//Gdy użytkownik jest sam na serwerze, dostaje od niego wiadomość.
	if ( sizeof($Server->wsClients) == 1 )
		$Server->wsSend($clientID, "Jesteś jedyną osobą na serwerze.");
	else
		//Wysłanie wiadomości do wszystkich na serwerze, oprócz osoby wysyłającej
		foreach ( $Server->wsClients as $id => $client )
			if ( $id != $clientID )
				$Server->wsSend($id, "Odwiedzający $clientID ($ip) napisał \"$message\"");
			// ID odwiedzającego, jego IP i wiadomość
}

//Kiedy klient zostanie podłączony do serwera
function wsOnOpen($clientID)
{
	global $Server;
	$ip = long2ip( $Server->wsClients[$clientID][6] );

	$Server->log( "$ip ($clientID) polaczyl sie." );

	//Wyślij wszystkim wiadomość kto się podłączył
	foreach ( $Server->wsClients as $id => $client )
		if ( $id != $clientID )
			$Server->wsSend($id, "Odwiedzający $clientID ($ip) dołącza do rozmowy.");
}

//Kiedy klient rozłącza się z serwerem
function wsOnClose($clientID, $status) {
	global $Server;
	$ip = long2ip( $Server->wsClients[$clientID][6] );

	$Server->log( "$ip ($clientID) rozlaczyl sie." );

	//Poinformowanie innych, kto wyszedł z czatu.
	foreach ( $Server->wsClients as $id => $client )
		$Server->wsSend($id, "Odwiedzający $clientID ($ip) opuścił pokój.");
}

//Start serwera.
$Server = new PHPWebSocket();
$Server->bind('message', 'wsOnMessage');
$Server->bind('open', 'wsOnOpen');
$Server->bind('close', 'wsOnClose');
// alternatively use: gethostbyaddr(gethostbyname($_SERVER['SERVER_NAME']))
$Server->wsStartServer('127.0.0.1', 9300);

?>